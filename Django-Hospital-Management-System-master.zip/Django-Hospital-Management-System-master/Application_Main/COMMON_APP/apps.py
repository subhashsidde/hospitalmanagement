from django.apps import AppConfig


class CommonAppConfig(AppConfig):
    name = 'COMMON_APP'
