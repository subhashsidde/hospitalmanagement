from django.apps import AppConfig


class DocterConfig(AppConfig):
    name = 'DOCTER'
